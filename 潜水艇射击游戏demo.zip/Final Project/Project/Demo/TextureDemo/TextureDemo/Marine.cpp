#include "Marine.h"



Marine::Marine(glm::vec3 &entityPos, glm::vec3 &targetPos, GLuint entityTexture, GLint entityNumElements)
	: GameObject(entityPos, entityTexture, entityNumElements)
{
	target = glm::vec2(targetPos.x,targetPos.y);
	agent = glm::vec2(entityPos.x, entityPos.y);
	mass = 0.1f;
	max_force = 50;
	max_speed = 0.2;


}

glm::vec2 Marine::normalize(glm::vec2 vec)
{
	float l = vec.length();
	if (l > 0.0f) {
		vec *= 1.0f / 1;
	}

	return vec;
}

glm::vec2 Marine::turncate(glm::vec2 vec, float max)
{
	if (vec.length() > max) {
		vec = normalize(vec) * max;
	}
	return vec;
}


void Marine::update(double deltaTime)
{

	if (position.x <= -8 || position.x >= 39) {
		position += glm::vec3(-0.05, 0.05, 0)*velocity;
		velocity = glm::vec3(-0.5, 0.5, 0)*velocity;
	}




	if (position.y <= -72 || position.y >= 5) {
		position += glm::vec3(0.05, -0.05, 0)*velocity;
		velocity = glm::vec3(0.5, -0.5, 0)*velocity;
	}

	if (glm::length(agent - target) < 18) {
		glm::vec2 desiredVelocity = agent - target;

		desiredVelocity = normalize(desiredVelocity);
		desiredVelocity *= max_speed;
		glm::vec2 steeringForce = (desiredVelocity - max_speed);
		steeringForce /= max_speed;
		steeringForce *= max_force;

		glm::vec2 acceleration = steeringForce / mass;
		velocity += glm::vec3((acceleration * (float)deltaTime), 0);
		velocity = glm::vec3(turncate(glm::vec2(velocity.x, velocity.y), max_speed), 0);

		position = position + 0.1f*velocity * (float)deltaTime;
	}
	else {
		velocity = glm::vec3(0, 0, 0);
	}



}

void Marine::render(Shader & shader)
{
	shader.enable();
	shader.SetAttributes_sprite();
	glBindTexture(GL_TEXTURE_2D, texture);

	glm::mat4 scaleMatrix = glm::scale(glm::mat4(), glm::vec3(facing, 1.5, 1));
	glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), position);


	glm::mat4 transformationMatrix = translationMatrix * scaleMatrix;
	shader.setUniformMat4("transformationMatrix", transformationMatrix);
	shader.setUniform2f("offset", glm::vec2(0, 0));
	shader.setUniform4f("basecl", glm::vec4(0, 0, 0, 0));

	// Draw the entity
	glDrawElements(GL_TRIANGLES, numElements, GL_UNSIGNED_INT, 0);
}



