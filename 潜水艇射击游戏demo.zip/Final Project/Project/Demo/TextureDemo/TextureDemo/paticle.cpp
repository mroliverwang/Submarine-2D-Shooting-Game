#include "paticle.h"
paticle::paticle(glm::vec3 &entityPos, GLuint entityTexture, GLint entityNumElements, float destroy_time, GameObject *att,std::string t) :
	GameObject(entityPos, entityTexture, entityNumElements) {
	dt = destroy_time;
	type = t;
	attach = att;
};

paticle::paticle(glm::vec3 &entityPos, GLuint entityTexture, GLint entityNumElements, float destroy_time, std::string t) :
	GameObject(entityPos, entityTexture, entityNumElements) {
	dt = destroy_time;
	type = t;
	attach = NULL;
};

void paticle::update(double deltaTime) {
	
	if (attach != NULL) {
		
		position = attach->getPosition();
	}
	dt -= deltaTime;
	if (dt <= 0 && !donot_destroy_ontime ) {
		destroy = true;
	}

	

	// Call the parent's update method to move the object
	GameObject::update(deltaTime);
}


void paticle::renderParticles(Shader &shader, double deltaTime) {

	
	shader.enable();
	shader.SetAttributes_particle();
	//static float mytime = 0.0;
	
	time += (float)deltaTime;
	
	// Bind the particle texture
	glBindTexture(GL_TEXTURE_2D, texture);




	// Set the transformation matrix for the shader
	glm::mat4 scaling = glm::scale(glm::mat4(1.0), glm::vec3(0.5, 1.0, 0.2));
	glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), position);

	// Set the transformation matrix in the shader
	// TODO: Multiply your new transformations to make the transformationMatrix
	glm::mat4 transformationMatrix = translationMatrix * scaling;
	shader.setUniformMat4("transformationMatrix", transformationMatrix);
	shader.setUniform2f("offset", glm::vec2(0, 0));
	shader.setUniform4f("basecl", glm::vec4(0, 0, 0, 0));
	shader.setUniform1f("time", time);
	// Draw the entity
	glDrawElements(GL_TRIANGLES, 204000, GL_UNSIGNED_INT, 0);
}

