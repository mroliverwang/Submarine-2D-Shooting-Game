#include "Enemy.h"

#include "Window.h"


Enemy::Enemy(glm::vec3 &entityPos, GLuint entityTexture, GLint entityNumElements, int shieldN)
	: GameObject(entityPos, entityTexture, entityNumElements) 
{
	ammo = 2;
	shieldNumber = shieldN;
}







void Enemy::update(double deltaTime) {

	position += velocity * (float)deltaTime;
	
	//the movement of enemies when player is not nearby
	if (alert != 1) {

		if (position.y > -8) {
			if (velocity.x > 0) {
				facing = 1.5;
			}
			else if (velocity.x < 0) {
				facing = -1.5;
			}

			if (position.x > 35) {
				velocity = glm::vec3(-1.05, 0, 0);
			}
			if (position.x < 18) {
				velocity = glm::vec3(1.05, 0, 0);
			}
		}

		else if (position.y <= -8 && position.y > -17) {
			if (velocity.x > 0) {
				facing = 1.5;
			}
			else if (velocity.x < 0) {
				facing = -1.5;
			}

			if (position.x > 15) {
				velocity = glm::vec3(-1.05, +0.3, 0);
			}
			if (position.x < -2) {
				velocity = glm::vec3(1.05, -0.3, 0);
			}
		}

		else if (position.y <= -15 && position.y > -25) {
			if (velocity.x > 0) {
				facing = 1.5;
			}
			else if (velocity.x < 0) {
				facing = -1.5;
			}

			if (position.x > 22) {
				velocity = glm::vec3(-1.05, 0, 0);
			}
			if (position.x < 16) {
				velocity = glm::vec3(1.05, 0, 0);
			}
			
		}

		else if (position.y <= -25 && position.y > -50) {
			if (velocity.x > 0) {
				facing = 1.5;
			}
			else if (velocity.x < 0) {
				facing = -1.5;
			}
			float time = glfwGetTime();
			if (position.x > 25) {
				
				velocity = glm::vec3(sin(time), cos(time), 0);
			}
			else if (position.x < 20) {
				velocity = glm::vec3(cos(time), sin(time), 0);
			}
			else {
				velocity = glm::vec3(0, 2.5*sin(time), 0);
			}
		}



	}
	//try to avoid collision with player
	else if (alert == 1) {
		velocity = glm::vec3(-0.2*(facing),0 , 0);
	}

	



	//collision with edge of the game
	if (position.x <= -8 || position.x >= 39) {
		position += glm::vec3(-0.05, 0.05, 0)*velocity;
		velocity = glm::vec3(-0.5, 0.5, 0)*velocity;
	}




	if (position.y <= -72 || position.y >= 5) {
		position += glm::vec3(0.05, -0.05, 0)*velocity;
		velocity = glm::vec3(0.5, -0.5, 0)*velocity;
	}





	//update the player's ammo and cooldown
	if (cooldown > 0) {
		cooldown -= 2 * (float)deltaTime;
	}

	if (ammo < 2) {
		ammo += 0.8*(float)deltaTime;
	}





	// Call the parent's update method to move the object
	GameObject::update(deltaTime);
}


void Enemy::render(Shader &shader) {
	shader.enable();
	shader.SetAttributes_sprite();
	// Bind the entities texture
	glBindTexture(GL_TEXTURE_2D, texture);

	glm::mat4 scaleMatrix = glm::scale(glm::mat4(), glm::vec3(facing, 1.5, 1));
	glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), position);


	glm::mat4 transformationMatrix = translationMatrix * scaleMatrix;
	shader.setUniformMat4("transformationMatrix", transformationMatrix);

	shader.setUniform2f("offset", glm::vec2(0, 0));
	//different color indicating shield number
	if (shieldNumber == 0) {
		shader.setUniform4f("basecl", glm::vec4(0, 0, 0, 0));

	}

	if (shieldNumber == 1) {
		shader.setUniform4f("basecl", glm::vec4(0.5, 0,0,1));

	}
	if (shieldNumber == 2) {
		shader.setUniform4f("basecl", glm::vec4(0.5, 0.5, 0, 1));

	}
	if (shieldNumber == 3) {
		shader.setUniform4f("basecl", glm::vec4(0, 0.5, 0, 1));

	}



	// Draw the entity
	glDrawElements(GL_TRIANGLES, numElements, GL_UNSIGNED_INT, 0);

}