#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#define GLEW_STATIC
#include <GL/glew.h> // window management library
#include <GL/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp> //
#include <SOIL/SOIL.h> // read image file
#include <chrono>
#include <thread>
#include <locale>
#include <cstdlib>
#include <cmath>

#include "Shader.h"
#include "common.h"
#include "Window.h"
#include "PlayerGameObject.h"
#include "Graph.h"
#include "Node.h"
#include "Coral.h"
#include "Bullet.h"
#include "Enemy.h"
#include "Boss.h"
#include "Heal.h"
#include "Shield.h"
#include "Upgrade.h"
#include "Marine.h"
#include "paticle.h"

float mult = 1.6; //play with this if you want a bigger or smaller graph but still framed the same

// Macro for printing exceptions
#define PrintException(exception_object)\
	std::cerr << exception_object.what() << std::endl

// Globals that define the OpenGL window and viewport
const std::string window_title_g = "PROJECT 2501";

extern int window_width_g  = 1200;
extern int window_height_g = 900;
extern float cameraZoom    = mult * 0.05f;
extern float aspectRatio   = (float)window_height_g / (float)window_width_g;
//extern GLFWwindow* window;


const glm::vec3 viewport_background_color_g(0.0, 0.51, 1);

GLuint sprite_vbo;
GLuint sprite_ebo;
// Global texture info
GLuint tex[21];

// Global game object info
std::vector<GameObject*> gameObjects;
std::vector<GameObject*> coralObjects;
std::vector<GameObject*> edge;
std::vector<GameObject*> bullets;
std::vector<GameObject*> enemyBullets;
std::vector<GameObject*> breakableCoral;
std::vector<GameObject*> enemy;
std::vector<GameObject*> boss;
std::vector<GameObject*> bossBullets;
std::vector<GameObject*> heal;
std::vector<GameObject*> weapon;
std::vector<GameObject*> freeze;
std::vector<GameObject*> shield;
std::vector<GameObject*> upgradeBullet;
std::vector<GameObject*> shielding;
std::vector<Marine*> whales;
std::vector<paticle*> paticles;

// Create the geometry for a square (with two triangles)
// Return the number of array elements that form the square
int CreateSquare(void) {
	// The face of the square is defined by four vertices and two triangles



	GLfloat vertex[]  = {
		//  square (two triangles)
		   //  Position      Color             Texcoords
		-0.5f, 0.5f,	 1.0f, 0.0f, 0.0f,		0.0f, 0.0f, // Top-left
		0.5f, 0.5f,		 0.0f, 1.0f, 0.0f,		1.0f, 0.0f, // Top-right
		0.5f, -0.5f,	 0.0f, 0.0f, 1.0f,		1.0f, 1.0f, // Bottom-right
		-0.5f, -0.5f,	 1.0f, 1.0f, 1.0f,		0.0f, 1.0f  // Bottom-left
	};


	GLuint face[] = {
		0, 1, 2, // t1
		2, 3, 0  //t2
	};

	GLuint vbo, ebo;

	// Create buffer for vertices
	glGenBuffers(1, &sprite_vbo);
	glBindBuffer(GL_ARRAY_BUFFER, sprite_vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex), vertex, GL_STATIC_DRAW);

	// Create buffer for faces (index buffer)
	glGenBuffers(1, &sprite_ebo);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sprite_ebo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(face), face, GL_STATIC_DRAW);

	// Return number of elements in array buffer (6 in this case)
	return sizeof(face) / sizeof(GLuint);
}


void setthisTexture(GLuint w, char *fname){
	glBindTexture(GL_TEXTURE_2D, w);

	int width, height;
	unsigned char* image = SOIL_load_image(fname, &width, &height, 0, SOIL_LOAD_RGBA);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
	SOIL_free_image_data(image);

	// Texture Wrapping
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	// Texture Filtering
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
}

void setallTexture(void){
	glGenTextures(21, tex);
	setthisTexture(tex[0], "co1.png");
	setthisTexture(tex[1], "sub.png");
	setthisTexture(tex[2], "b2.png");
	setthisTexture(tex[3], "co.png");
	setthisTexture(tex[4], "cccc.png");
	setthisTexture(tex[5], "heart.png");
	setthisTexture(tex[6], "sub3.png");
	setthisTexture(tex[7], "ufo.png");
	setthisTexture(tex[8], "gun.png");
	setthisTexture(tex[9], "g2.png");
	setthisTexture(tex[10], "b33.png");
	setthisTexture(tex[11], "dollar.png");
	setthisTexture(tex[12], "shop.png");
	setthisTexture(tex[13], "upgrade.png");
	setthisTexture(tex[14], "shield.png");
	setthisTexture(tex[15], "freeze.png");
	setthisTexture(tex[16], "bomb.png");
	setthisTexture(tex[17], "whale.png");
	setthisTexture(tex[18], "text.png");
	setthisTexture(tex[19], "orb.png");
	setthisTexture(tex[20], "rock.png");
	glBindTexture(GL_TEXTURE_2D, tex[0]);
}


//a function that performs player's movement and update the 'next' node to go 
void gameLoop(Graph *gameworld) {
	GameObject* currentGameObject = gameObjects[0];
	Node& start = gameworld->getNode(gameworld->getStartId());
	glm::vec3 curPo = currentGameObject->getPosition();
	Node end = gameworld->getNode(gameworld->getEndId());

	//path planing
	
	std::vector<Node*> path = gameworld->getPath1();
	std::vector<Node*>* p = gameworld->getPath();
	
	
	
	//move player towards destination node
	if ((end.getX() - curPo.x)*(end.getX() - curPo.x) < 0.01 && (end.getY() - curPo.y)*(end.getY() - curPo.y) < 0.01) {
		currentGameObject->setVelocity(glm::vec3(0, 0, 0.0f));
	}
	
	
	//update the destination node if previous nodes on path is reached
	if (path.size() > 1) {
		if ((path[1]->getX() != end.getX() || path[1]->getY() != end.getY()) && (start.getX() - curPo.x)*(start.getX() - curPo.x) < 0.01 && (start.getY() - curPo.y)*(start.getY() - curPo.y) < 0.01) {
			currentGameObject->setVelocity(glm::vec3((path[1]->getX()-start.getX()), (path[1]->getY() - start.getY()), 0.0f));
			start.setOnPath(false);
			gameworld->setStart(path[1]->getId());
			
			p->erase(p->begin());
		}

		if (path[1]->getY() == end.getY() && path[1]->getX() == end.getX() && (start.getX() - curPo.x)*(start.getX() - curPo.x) < 0.01 && (start.getY() - curPo.y)*(start.getY() - curPo.y) < 0.01) {

			currentGameObject->setVelocity(glm::vec3((path[1]->getX() - start.getX()), (path[1]->getY() - start.getY()), 0.0f));
			gameworld->setStart(path[1]->getId());
			gameworld->setEnd(path[1]->getId());
		}
		
	}
	
}




//set up the control of the shooting with two different weapon
void control(void)
{

	GameObject *player = gameObjects[0];
	glm::vec3 curvel = player->getVelocity();

	if (glfwGetKey(Window::getWindow(), GLFW_KEY_J) == GLFW_PRESS) {

		if (player->getCooldown() <= 0 && player->getAmmo() >= 1) {
			if (player->getUpgrade() == 0) {
				// shoot the bullets
				bullets.push_back(new Bullet(player->getPosition(), tex[2], 6));
				GameObject *bullet = bullets.back();
				if (player->getFacing() == 1.5 || player->getFacing() == -1.5) {
					bullet->setVelocity(glm::vec3(7 * (player->getFacing()), 0, 0));
					bullet->setFacing(player->getFacing());
				}
				else {
					bullet->setVelocity(glm::vec3(0, -7, 0));
				}


				//set new cooldown and new ammo amount
				float newC = 0.5f;
				player->setCooldown(newC);
				float newA = player->getAmmo() - 1;
				player->setAmmo(newA);
			}

			else {
				upgradeBullet.push_back(new Upgrade(player->getPosition(), tex[16], 6));
				GameObject *bullet = upgradeBullet.back();
				
				bullet->setVelocity(glm::vec3(5 * (player->getFacing()), 8, 0));
				bullet->setFacing(player->getFacing());
				


				//set new cooldown and new ammo amount
				float newC = 0.5f;
				player->setCooldown(newC);
				float newA = player->getAmmo() - 1;
				player->setAmmo(newA);



			}







		}
	}

}


//functions for the start page
void renderScreen(Shader &shader, int size, GLuint texture) {
	glClearColor(viewport_background_color_g[0],
		viewport_background_color_g[1],
		viewport_background_color_g[2], 0.0);
	glDepthMask(GL_TRUE); // allow writes to depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	// Draw the square

	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glBlendEquation(GL_FUNC_ADD);


	// Select proper shader program to use
	glUseProgram(shader.getShaderID());

	glBindBuffer(GL_ARRAY_BUFFER, sprite_vbo);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sprite_ebo);
	shader.SetAttributes_sprite();

	// Bind the entities texture
	glBindTexture(GL_TEXTURE_2D, texture);

	// Setup the transformation matrix for the shader
	glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(0.4f, -0.0, 1.0f));
	glm::mat4 rotationMatrix = glm::rotate(glm::mat4(1.0), 90.0f, glm::vec3(0.0f, 0.0f, 1.0f));
	glm::mat4 scaleMatrix = glm::scale(glm::mat4(1.0f), glm::vec3(0.75f, 0.75f, 0.75f));
	// Set the transformation matrix in the shader
	glm::mat4 transformationMatrix = glm::scale(glm::mat4(1.0f), glm::vec3(10, 10, 1.0));
	//transformationMatrix = rotationMatrix * translationMatrix  * scaleMatrix;
	shader.setUniformMat4("transformationMatrix", transformationMatrix);
	GLint color_loc = glGetUniformLocation(shader.getShaderID(), "colorMod");
	glUniform3f(color_loc, 0.0f, 0.0f, 0.0f);
	// Draw the entity
	glDrawElements(GL_TRIANGLES, size, GL_UNSIGNED_INT, 0);

}

void renderText(std::string &stringToRender, Shader &textShader, glm::vec3 pos) {
	// Enable the shader and bind the proper text spritesheet texture
	textShader.enable();
	textShader.SetAttributes_sprite();
	glBindTexture(GL_TEXTURE_2D, tex[18]);


	// Loop through each character and draw it
	for (int i = 0; i < stringToRender.size(); i++) {
		// We need to get the character and map it to a UV coordinate the represents where it is located in the text spritesheet texture
		// First get the character and make sure it is an upper case character (less cases to cover)
		int ascii = (int)std::toupper(stringToRender[i], std::locale());

		// Convert our ascii value into the range of [0, 35] (0, 1, 2, ... , A, B, C, .... , Z)
		if (ascii > 57)
			ascii -= 7;
		ascii -= 48;

		// Get the row and column of the character in our sprite sheet. Then we will let our vertex shader calculate the proper UVs
		int spritesheetSize = 6;
		float charUVSize = 1.0f / spritesheetSize;
		int charRow = ascii / spritesheetSize;
		int charCol = ascii % spritesheetSize;

		// Before we draw, we need to setup the transformation matrix for the text (doesn't use a view matrix)
		glm::mat4 translation = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0.025*i, 0, 0));
		glm::mat4 scale = glm::scale(glm::mat4(1.0f), glm::vec3(0.04f, 0.05f, 1.0f));
		glm::mat4 transformationMatrix = translation * scale;

		// Setup uniforms
		textShader.setUniform1f("UVSize", charUVSize);
		textShader.setUniform1i("charCol", charCol);
		textShader.setUniform1i("charRow", charRow);
		textShader.setUniformMat4("transformationMatrix", transformationMatrix);
		textShader.setUniform3f("textColour", glm::vec3(1.0f, 0.0f, 0.0f));

		// Finally draw the character
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
	}
}

























// Main function that builds and runs the game
int main(void){
	try {
		// Seed for generating random numbers with rand()
		srand((unsigned int)time(0));

		// Setup window
		Window window(window_width_g, window_height_g, window_title_g);

		//setup shaders
		Shader damage("damage.vert", "shader.frag", true);


		Shader shader("shader.vert", "shader.frag", true);


		Shader boom("boom.vert", "shader.frag", true);


		Shader textShader("textShader.vert", "textShader.frag", false);

		textShader.SetAttributes_sprite();




		// Set up z-buffer for rendering
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LESS);

		// Enable Alpha blending
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		// Create geometry of the square
		int size = CreateSquare();

		

		// Set up the textures
		setallTexture();

		

		//Setup widxheight graph
		float mod = 13 / mult;  //allows you to play with the size of the graph by changing mult before running
		int wid = 4 * mod;
		int height = 3 * mod;
		int state = 0;
		


	


		
		Graph gameworld = Graph(50, 80, GameObject(glm::vec3(0.0f), tex[0], CreateSquare()));
		//initialize player game object
		Node n = gameworld.getNode(gameworld.getStartId());
		gameObjects.push_back(new PlayerGameObject(glm::vec3(n.getX(), n.getY(), 0.0f), tex[1], 6));



		//initialize enemies
		enemy.push_back(new Enemy(glm::vec3(n.getX()+20, n.getY(), 0.0f), tex[6], 6, 0));
		enemy.push_back(new Enemy(glm::vec3(n.getX()+40, n.getY()-2, 0.0f), tex[6], 6, 0));
		enemy.push_back(new Enemy(glm::vec3(n.getX()+15, n.getY()-5, 0.0f), tex[6], 6, 0));

		enemy.push_back(new Enemy(glm::vec3(n.getX(), n.getY() - 10, 0.0f), tex[6], 6, 1));
		enemy.push_back(new Enemy(glm::vec3(n.getX()+15, n.getY() - 19, 0.0f), tex[6], 6, 2));
		enemy.push_back(new Enemy(glm::vec3(n.getX()+1 , n.getY() - 13, 0.0f), tex[6], 6, 2));
		enemy.push_back(new Enemy(glm::vec3(n.getX()+19 , n.getY()-25, 0.0f), tex[6], 6,1));

		enemy.push_back(new Enemy(glm::vec3(n.getX() + 35, n.getY() - 35, 0.0f), tex[6], 6, 2));
		enemy.push_back(new Enemy(glm::vec3(n.getX() + 10, n.getY() - 40, 0.0f), tex[6], 6, 3));
		enemy.push_back(new Enemy(glm::vec3(n.getX() + 15, n.getY() - 43, 0.0f), tex[6], 6, 2));
		enemy.push_back(new Enemy(glm::vec3(n.getX() + 25, n.getY() - 41, 0.0f), tex[6], 6, 3));
		enemy.push_back(new Enemy(glm::vec3(n.getX() + 30, n.getY() - 40, 0.0f), tex[6], 6, 3));

		boss.push_back(new Boss(glm::vec3(n.getX() + 30, n.getY() - 70, 0.0f), tex[7],tex[8], 6));

		whales.push_back(new Marine(glm::vec3(n.getX() + 11, n.getY() - 35, 0.0f), gameObjects[0]->getPosition(), tex[17], 6));
		whales.push_back(new Marine(glm::vec3(n.getX() + 19, n.getY() - 29, 0.0f), gameObjects[0]->getPosition(), tex[17], 6));

		//set up upgrades
		heal.push_back(new Heal(glm::vec3(1 , 1, 0.0f),tex[5], 6));
		heal.push_back(new Heal(glm::vec3(-3, -14, 0.0f), tex[5], 6));
		heal.push_back(new Heal(glm::vec3(1, -70, 0.0f), tex[5], 6));
		heal.push_back(new Heal(glm::vec3(2, -50, 0.0f), tex[5], 6));
		heal.push_back(new Heal(glm::vec3(-4, -35, 0.0f), tex[5], 6));
		heal.push_back(new Heal(glm::vec3(-6, -55, 0.0f), tex[5], 6));
		heal.push_back(new Heal(glm::vec3(-6, -40, 0.0f), tex[5], 6));
		heal.push_back(new Heal(glm::vec3(-6, -60, 0.0f), tex[5], 6));

		weapon.push_back(new Heal(glm::vec3(-5, -25, 0.0f), tex[13], 6));
		weapon.push_back(new Heal(glm::vec3(-2, -68, 0.0f), tex[13], 6));

		shield.push_back(new Heal(glm::vec3(28, -20, 0.0f), tex[14], 6));
		shield.push_back(new Heal(glm::vec3(-2, -60, 0.0f), tex[14], 6));
		shield.push_back(new Heal(glm::vec3(-2, -56, 0.0f), tex[14], 6));

		freeze.push_back(new Heal(glm::vec3(25, -50, 0.0f), tex[15], 6));
		freeze.push_back(new Heal(glm::vec3(10, -56, 0.0f), tex[15], 6));




		//set up coral map
		for (int i = 0; i < 50; i++) {
			edge.push_back(new Coral(glm::vec3(gameworld.getNode(i).getX(), gameworld.getNode(i).getY(), 0.0f), tex[0], 6));
			//std::cout << gameworld.getNode(i).getX() << std::endl;
		}
		for (int x = 50; x < 3950; x += 50) {
			edge.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[0], 6));
		}

		for (int v = 3950; v < 4000; v++) {
			edge.push_back(new Coral(glm::vec3(gameworld.getNode(v).getX(), gameworld.getNode(v).getY(), 0.0f), tex[0], 6));
			std::cout << gameworld.getNode(v).getY() << std::endl;
		}

		for (int x = 49; x < 4000; x += 50) {
			edge.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[0], 6));
		}

		for (int x = 401; x < 405; x++) {
			breakableCoral.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[3], 6));
		}

		for (int x = 405; x < 420; x++) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 469; x < 669; x+=50) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 620; x < 640; x++) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}


		for (int x = 949; x > 940; x--) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 940; x < 1284; x+=49) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 1333; x < 1584; x += 50) {
			breakableCoral.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[3], 6));
		}

		for (int x = 1633; x < 1645; x++) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 1632; x > 1622; x--) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 1622; x > 1111; x-=51) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 1111; x > 1105; x--) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 675; x < 1226; x+=50) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 2551; x < 2560; x++) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 2609; x < 3410; x += 50) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 2755; x < 3556; x += 50) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 3605; x < 3615; x++) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 3615; x > 2516; x -= 50) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 2566; x < 2590; x++) {
			coralObjects.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[4], 6));
		}

		for (int x = 2564; x > 2559; x--) {
			breakableCoral.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[3], 6));
		}

		for (int x = 2914; x > 2909; x--) {
			breakableCoral.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[3], 6));
		}


		for (int x = 1111; x > 1100; x--) {
			breakableCoral.push_back(new Coral(glm::vec3(gameworld.getNode(x).getX(), gameworld.getNode(x).getY(), 0.0f), tex[3], 6));
		}






		// Run the main loop
		double lastTime = glfwGetTime();
		while (!glfwWindowShouldClose(window.getWindow())) {
			
			// Clear background
			window.clear(viewport_background_color_g);
			//start page
			if (state == 0) {
				//std::cout << state;
				//renderScreen(shader, size, tex[9]);
				glClearColor(viewport_background_color_g[0],
					viewport_background_color_g[1],
					viewport_background_color_g[2], 0.0);
				glDepthMask(GL_TRUE); // allow writes to depth buffer
				glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


				// Draw the square

				glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
				glBlendEquation(GL_FUNC_ADD);


				// Select proper shader program to use
				glUseProgram(shader.getShaderID());

				glBindBuffer(GL_ARRAY_BUFFER, sprite_vbo);
				glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sprite_ebo);
				shader.SetAttributes_sprite();

				// Bind the entities texture
				glBindTexture(GL_TEXTURE_2D, tex[10]);

				// Setup the transformation matrix for the shader
				glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(0.4f, -0.0, 1.0f));
				glm::mat4 rotationMatrix = glm::rotate(glm::mat4(1.0), 90.0f, glm::vec3(0.0f, 0.0f, 1.0f));
				glm::mat4 scaleMatrix = glm::scale(glm::mat4(1.0f), glm::vec3(0.75f, 0.75f, 0.75f));
				// Set the transformation matrix in the shader
				glm::mat4 transformationMatrix = glm::scale(glm::mat4(1.0f), glm::vec3(10, 10, 1.0));
				//transformationMatrix = rotationMatrix * translationMatrix  * scaleMatrix;
				shader.setUniformMat4("transformationMatrix", transformationMatrix);
				GLint color_loc = glGetUniformLocation(shader.getShaderID(), "colorMod");
				glUniform3f(color_loc, 0.0f, 0.0f, 0.0f);
				// Draw the entity
				glDrawElements(GL_TRIANGLES, size, GL_UNSIGNED_INT, 0);

				glfwPollEvents();


				renderText(std::string("Warning"), textShader, glm::vec3(0, 0.9, -0.2));

				renderText(std::string("A group of aliens from Kepler Planet are occupying the seafloor "), textShader, glm::vec3(-0.80, 0.7, -0.2));
				//renderText(std::string(std::to_string(currency)), textShader, glm::vec3(0.8, 0.65, -0.2));
				renderText(std::string("trying to steal the resouces from us! "), textShader, glm::vec3(-0.80, 0.5, -0.2));
				//renderText(std::string(std::to_string(enemyDestoried)), textShader, glm::vec3(0.8, 0.45, -0.2));
				renderText(std::string("Warrior, you will sail your submarine to defeat and stop the aliens!"), textShader, glm::vec3(-0.80, 0.30, -0.2));

				renderText(std::string("Please press Enter to start game"), textShader, glm::vec3(0.2, -0.70, -0.2));
				//renderText(std::string(std::to_string(Health)), textShader, glm::vec3(0.8, 0.25, -0.2));
				if (glfwGetKey(Window::getWindow(), GLFW_KEY_ENTER) == GLFW_PRESS) {
					state = 1;
				}
				glfwSwapBuffers(window.getWindow());
			}

			//game start
			else if (state == 1) {

				// Calculate delta time
				double currentTime = glfwGetTime();
				double deltaTime = currentTime - lastTime;
				lastTime = currentTime;

				

				//focus
				GameObject *player = gameObjects[0];
				glm::vec3 position = player->getPosition();
				glm::mat4 viewMatrix = glm::scale(glm::mat4(1.0f), glm::vec3(cameraZoom, cameraZoom, cameraZoom));
				// player will always display on the center
				glm::mat4 translateMatrix = glm::translate(glm::mat4(1.0f), position);


				// Select proper shader program to use
				shader.enable();
				shader.setUniformMat4("viewMatrix", viewMatrix / translateMatrix);

				damage.enable();
				damage.setUniformMat4("viewMatrix", viewMatrix / translateMatrix);

				boom.enable();
				boom.setUniformMat4("viewMatrix", viewMatrix / translateMatrix);
				

				



				float oldMult = mult;
				//user input
				if (glfwGetKey(Window::getWindow(), GLFW_KEY_MINUS) == GLFW_PRESS) {
					if (mult > 0.5) {
						mult -= 0.01;
					}

				}
				if (glfwGetKey(Window::getWindow(), GLFW_KEY_EQUAL) == GLFW_PRESS) {
					if (mult < 4) {
						mult += 0.01;
					}
				}
				cameraZoom = mult * 0.05f;
				mod = 13 / mult;  //allows you to play with the size of the graph by changing mult before running
				wid = 4 * mod - 1;
				height = 3 * mod - 1;


				//apply controls
				control();

				int ammo;
				int health;
				int score;

				// Update and render all game objects

				for (int i = 0; i < paticles.size(); i++) {
					if (paticles[i]->destroy) {
						paticles.erase(paticles.begin() + i);
						continue;
					}

					paticles[i]->update(deltaTime);
					if (paticles[i]->getType().compare("damage") == 0) {
						paticles[i]->renderParticles(damage, deltaTime);
					}
					else if (paticles[i]->getType().compare("boom") == 0) {
						paticles[i]->renderParticles(boom, deltaTime);
					}


				}




				//update player
				for (int i = 0; i < gameObjects.size(); i++) {
					// Get the current object
					GameObject* currentGameObject = gameObjects[i];

					//updating collision and item pick up
					if (i == 0) {
						ammo = currentGameObject->getAmmo();
						health = currentGameObject->getHealth();
						score = currentGameObject->getScore();
						if (health <= 0) {
							exit(0);
						}

						for (int x = 0; x < coralObjects.size(); x++) {
							GameObject* curC = coralObjects[x];

							if ((currentGameObject->getPosition().x - curC->getPosition().x)*(currentGameObject->getPosition().x - curC->getPosition().x) < 1 && (currentGameObject->getPosition().y - curC->getPosition().y)*(currentGameObject->getPosition().y - curC->getPosition().y) < 1) {

								glm::vec3 curpo = currentGameObject->getPosition();
								glm::vec3 curv = currentGameObject->getVelocity();


								curpo += glm::vec3(-0.05, -0.05, 0)*curv;
								curv = glm::vec3(-0.5, -0.5, 0)*curv;

								currentGameObject->setPosition(curpo);
								currentGameObject->setVelocity(curv);

							}

						}


						for (int x = 0; x < breakableCoral.size(); x++) {
							GameObject* curC = breakableCoral[x];

							if ((currentGameObject->getPosition().x - curC->getPosition().x)*(currentGameObject->getPosition().x - curC->getPosition().x) < 1 && (currentGameObject->getPosition().y - curC->getPosition().y)*(currentGameObject->getPosition().y - curC->getPosition().y) < 1) {

								glm::vec3 curpo = currentGameObject->getPosition();
								glm::vec3 curv = currentGameObject->getVelocity();


								curpo += glm::vec3(-0.05, -0.05, 0)*curv;
								curv = glm::vec3(-0.5, -0.5, 0)*curv;

								currentGameObject->setPosition(curpo);
								currentGameObject->setVelocity(curv);

							}

						}

						for (int x = 0; x < enemy.size(); x++) {
							GameObject* curC = enemy[x];

							if ((currentGameObject->getPosition().x - curC->getPosition().x)*(currentGameObject->getPosition().x - curC->getPosition().x) < 1 && (currentGameObject->getPosition().y - curC->getPosition().y)*(currentGameObject->getPosition().y - curC->getPosition().y) < 1) {

								glm::vec3 curpo = currentGameObject->getPosition();
								glm::vec3 curv = currentGameObject->getVelocity();


								curpo += glm::vec3(-2.5, -1.5, 0);
								curv = glm::vec3(0, 0, 0);

								currentGameObject->setPosition(curpo);
								currentGameObject->setVelocity(curv);

								--health;
								currentGameObject->setHealth(health);

							}

							//update enemy when player enters the war zone
							float dis = glm::length(currentGameObject->getPosition() - curC->getPosition());
							if (dis < 10) {
								float a = 1.5;
								int b = 1;
								curC->setAlert(b);
								if (currentGameObject->getPosition().x > curC->getPosition().x) {
									curC->setFacing(a);

								}
								else if (currentGameObject->getPosition().x < curC->getPosition().x) {
									a = -1.5;
									curC->setFacing(a);
								}
								if (curC->getCooldown() <= 0 && curC->getAmmo() >= 1) {
									// shoot the bullets
									enemyBullets.push_back(new Bullet(curC->getPosition(), tex[9], 6));
									GameObject *bullet = enemyBullets.back();
									if (curC->getFacing() == 1.5 || curC->getFacing() == -1.5) {
										bullet->setVelocity(glm::vec3(5 * (curC->getFacing()), 0, 0));
										bullet->setFacing(curC->getFacing());
									}



									//set new cooldown and new ammo amount
									float newC = 0.5f;
									curC->setCooldown(newC);
									float newA = curC->getAmmo() - 1;
									curC->setAmmo(newA);
								}
								if (currentGameObject->getPosition().y > curC->getPosition().y) {
									curC->setVelocity(curC->getVelocity() + glm::vec3(0, 0.5, 0));

								}
								else if (currentGameObject->getPosition().y < curC->getPosition().y) {
									curC->setVelocity(curC->getVelocity() - glm::vec3(0, 0.5, 0));
								}

							}
							else {
								int a = 0;
								curC->setAlert(a);
							}
						}

						//update the boss to battle mode
						for (int x = 0; x < boss.size(); x++) {
							GameObject* curC = boss[x];

							//collision
							if ((currentGameObject->getPosition().x - curC->getPosition().x)*(currentGameObject->getPosition().x - curC->getPosition().x) < 10.5 && (currentGameObject->getPosition().y - curC->getPosition().y)*(currentGameObject->getPosition().y - curC->getPosition().y) < 10.5) {

								glm::vec3 curpo = currentGameObject->getPosition();
								glm::vec3 curv = currentGameObject->getVelocity();


								curpo += glm::vec3(-2.5, -1.5, 0);
								curv = glm::vec3(0, 0, 0);


								currentGameObject->setPosition(curpo);
								currentGameObject->setVelocity(curv);

								--health;
								currentGameObject->setHealth(health);

							}
							float dis = glm::length(currentGameObject->getPosition() - curC->getPosition());
							if (dis < 25) {
								if (curC->getCooldown() <= 0 && curC->getAmmo() >= 1) {
									float angle = curC->getAngle();
									// shoot the bullets
									bossBullets.push_back(new Bullet(curC->getPosition() + glm::vec3(glm::vec3(0, -0.2, 0)), tex[10], 6));
									GameObject *bullet = bossBullets.back();

									bullet->setVelocity(glm::vec3(5 * sin(angle), -5 * cos(angle), 0));
									bullet->setFacing(curC->getFacing());

									bossBullets.push_back(new Bullet(curC->getPosition(), tex[10], 6));
									GameObject *bullet1 = bossBullets.back();

									bullet1->setVelocity(glm::vec3(5 * sin(angle - 0.5), -5 * cos(angle - 0.5), 0));
									bullet1->setFacing(curC->getFacing());

									bossBullets.push_back(new Bullet(curC->getPosition(), tex[10], 6));
									GameObject *bullet2 = bossBullets.back();

									bullet2->setVelocity(glm::vec3(5 * sin(angle + 0.5), -5 * cos(angle + 0.5), 0));
									bullet2->setFacing(curC->getFacing());

									bossBullets.push_back(new Bullet(curC->getPosition(), tex[10], 6));
									GameObject *bullet3 = bossBullets.back();

									bullet3->setVelocity(glm::vec3(5 * sin(angle - 1.5), -5 * cos(angle - 1.5), 0));
									bullet3->setFacing(curC->getFacing());

									bossBullets.push_back(new Bullet(curC->getPosition(), tex[10], 6));
									GameObject *bullet4 = bossBullets.back();

									bullet4->setVelocity(glm::vec3(5 * sin(angle + 1.5), -5 * cos(angle + 1.5), 0));
									bullet4->setFacing(curC->getFacing());

									bossBullets.push_back(new Bullet(curC->getPosition(), tex[10], 6));
									GameObject *bullet5 = bossBullets.back();

									bullet5->setVelocity(glm::vec3(5 * sin(angle + 1.25), -5 * cos(angle + 1.25), 0));
									bullet5->setFacing(curC->getFacing());

									//game becomes harder when boss is low on health
									if (curC->getHealth() < 10) {
										bossBullets.push_back(new Bullet(curC->getPosition(), tex[10], 6));
										GameObject *bullet6 = bossBullets.back();

										bullet6->setVelocity(glm::vec3(5 * sin(angle + 1.75), -5 * cos(angle + 1.75), 0));
										bullet6->setFacing(curC->getFacing());

										bossBullets.push_back(new Bullet(curC->getPosition(), tex[10], 6));
										GameObject *bullet7 = bossBullets.back();

										bullet7->setVelocity(glm::vec3(5 * sin(angle + 1.1), -5 * cos(angle + 1.1), 0));
										bullet7->setFacing(curC->getFacing());

										bossBullets.push_back(new Bullet(curC->getPosition(), tex[10], 6));
										GameObject *bullet8 = bossBullets.back();

										bullet8->setVelocity(glm::vec3(5 * sin(angle - 0.25), -5 * cos(angle - 0.25), 0));
										bullet8->setFacing(curC->getFacing());

										bossBullets.push_back(new Bullet(curC->getPosition(), tex[10], 6));
										GameObject *bullet9 = bossBullets.back();

										bullet9->setVelocity(glm::vec3(5 * sin(angle - 0.75), -5 * cos(angle - 0.75), 0));
										bullet9->setFacing(curC->getFacing());

										bossBullets.push_back(new Bullet(curC->getPosition(), tex[10], 6));
										GameObject *bullet10 = bossBullets.back();

										bullet10->setVelocity(glm::vec3(5 * sin(angle + 0.25), -5 * cos(angle + 0.25), 0));
										bullet10->setFacing(curC->getFacing());
									}





									//set new cooldown and new ammo amount
									float newC = 0.5f;
									curC->setCooldown(newC);
									float newA = curC->getAmmo() - 1;
									curC->setAmmo(newA);
								}
							}

						}


						//item pick up
						for (int x = 0; x < heal.size(); x++) {
							GameObject* curC = heal[x];

							float dis = glm::length(currentGameObject->getPosition() - curC->getPosition());
							if (dis < 1) {
								if (glfwGetKey(Window::getWindow(), GLFW_KEY_F) == GLFW_PRESS) {
									if (currentGameObject->getScore() >= 2 && currentGameObject->getHealth() < 4) {
										int s = currentGameObject->getScore();
										int h = currentGameObject->getHealth();
										s -= 2;
										h += 1;
										currentGameObject->setScore(s);
										currentGameObject->setHealth(h);
										heal.erase(heal.begin() + x);
										break;
									}
								}

							}

						}

						for (int x = 0; x < shield.size(); x++) {
							GameObject* curC = shield[x];

							float dis = glm::length(currentGameObject->getPosition() - curC->getPosition());
							if (dis < 1) {
								if (glfwGetKey(Window::getWindow(), GLFW_KEY_F) == GLFW_PRESS) {
									if (currentGameObject->getScore() >= 2) {
										int s = currentGameObject->getScore();

										s -= 2;

										currentGameObject->setScore(s);
										shielding.push_back(new Shield(currentGameObject->getPosition(), tex[14], 6));
										shield.erase(shield.begin() + x);
										break;
									}
								}

							}

						}

						for (int x = 0; x < weapon.size(); x++) {
							GameObject* curC = weapon[x];

							float dis = glm::length(currentGameObject->getPosition() - curC->getPosition());
							if (dis < 1) {
								if (glfwGetKey(Window::getWindow(), GLFW_KEY_F) == GLFW_PRESS) {
									if (currentGameObject->getScore() >= 4) {
										int s = currentGameObject->getScore();

										s -= 4;

										currentGameObject->setScore(s);

										int t = 1;
										currentGameObject->setUpgrade(t);

										weapon.erase(weapon.begin() + x);
										break;
									}
								}

							}

						}

						for (int x = 0; x < freeze.size(); x++) {
							GameObject* curC = freeze[x];

							float dis = glm::length(currentGameObject->getPosition() - curC->getPosition());
							if (dis < 1 && boss.size()>0) {
								if (glfwGetKey(Window::getWindow(), GLFW_KEY_F) == GLFW_PRESS) {
									if (currentGameObject->getScore() >= 3) {
										int s = currentGameObject->getScore();

										s -= 3;
										int t = 1;
										currentGameObject->setScore(s);
										boss[0]->setFreeze(t);
										freeze.erase(freeze.begin() + x);
										break;
									}
								}

							}

						}

						//collision with whales
						for (int x = 0; x < whales.size(); x++) {
							GameObject* curC = whales[x];

							float dis = glm::length(currentGameObject->getPosition() - curC->getPosition());
							if (dis < 1) {
								if (currentGameObject->getScore() >= 1) {
									int s = currentGameObject->getScore();

									s -= 1;

									currentGameObject->setScore(s);

									glm::vec3 curpo = currentGameObject->getPosition();
									glm::vec3 curv = currentGameObject->getVelocity();


									curpo += glm::vec3(-2, -1, 0);
									curv = glm::vec3(0, 0, 0);

									currentGameObject->setPosition(curpo);
									currentGameObject->setVelocity(curv);

									break;
								}
							}

						}


















					}


					// Updates game objects
					currentGameObject->update(deltaTime);

					//reset color uniform.
					//GLint color_loc = glGetUniformLocation(shader.getShaderID(), "colorMod");
					//glUniform3f(color_loc, 0.0f, 0.0f, 0.0f);

					// Render game objects
					currentGameObject->render(shader);
				}







				//update coral
				for (int i = 0; i < coralObjects.size(); i++) {
					// Get the current object
					GameObject* currentCoral = coralObjects[i];

					// Render corals
					currentCoral->render(shader);
				}

				//updated edge coral
				for (int i = 0; i < edge.size(); i++) {
					// Get the current object
					GameObject* currentCoral = edge[i];





					// Render corals
					currentCoral->render(shader);
				}




				//update bullet and damage of the bullet
				for (int i = bullets.size() - 1; i >= 0; i--) {
					// Get the current object
					GameObject* b = bullets[i];

					glm::vec3 p = b->getPosition();
					glm::vec3 pp = gameObjects[0]->getPosition();
					if (p.x <= -8 || p.x >= 39 || p.y <= -72 || p.y >= 5) {
						bullets.erase(bullets.begin() + i);
					}

					float distance = glm::length(gameObjects[0]->getPosition() - b->getPosition());
					if (distance > 12.0f) {
						bullets.erase(bullets.begin() + i);
					}


					for (int x = 0; x < coralObjects.size(); x++) {
						GameObject* curC = coralObjects[x];

						if ((b->getPosition().x - curC->getPosition().x)*(b->getPosition().x - curC->getPosition().x) < 0.6 && (b->getPosition().y - curC->getPosition().y)*(b->getPosition().y - curC->getPosition().y) < 0.6) {

							bullets.erase(bullets.begin() + i);
							break;
						}

					}

					for (int x = breakableCoral.size() - 1; x >= 0; x--) {
						GameObject* curC = breakableCoral[x];

						if ((b->getPosition().x - curC->getPosition().x)*(b->getPosition().x - curC->getPosition().x) < 0.6 && (b->getPosition().y - curC->getPosition().y)*(b->getPosition().y - curC->getPosition().y) < 0.6) {
							int s = (gameObjects[0]->getScore()) + 1;
							gameObjects[0]->setScore(s);
							//bullets.erase(bullets.begin() + i);
							breakableCoral.erase(breakableCoral.begin() + x);
							break;

						}

					}

					for (int x = enemy.size() - 1; x >= 0; x--) {
						GameObject* curC = enemy[x];

						if ((b->getPosition().x - curC->getPosition().x)*(b->getPosition().x - curC->getPosition().x) < 0.6 && (b->getPosition().y - curC->getPosition().y)*(b->getPosition().y - curC->getPosition().y) < 0.6) {

							bullets.erase(bullets.begin() + i);
							if (curC->getShield() > 0) {
								int s = curC->getShield();
								s -= 1;
								curC->setShield(s);
							}
							else {
								paticles.push_back(new paticle(curC->getPosition(), tex[19], 6, 1, curC, "boom"));
								int s = (gameObjects[0]->getScore()) + 2;
								gameObjects[0]->setScore(s);
								enemy.erase(enemy.begin() + x);
							}
							break;

						}

					}

					for (int x = boss.size() - 1; x >= 0; x--) {
						GameObject* curC = boss[x];

						if ((b->getPosition().x - curC->getPosition().x)*(b->getPosition().x - curC->getPosition().x) < 7 && (b->getPosition().y - curC->getPosition().y)*(b->getPosition().y - curC->getPosition().y) < 7) {

							bullets.erase(bullets.begin() + i);
							if (curC->getHealth() - 1 != 0) {
								int h = curC->getHealth() - 1;
								curC->setHealth(h);
								//particle effects as smoke when boss is low on health
								if (curC->getHealth() <= 10) {
									paticles.push_back(new paticle(curC->getPosition(), tex[20], 6, 10, curC, "damage"));
								}
							}
							else {
								boss.erase(boss.begin() + x);
								paticles.push_back(new paticle(curC->getPosition(), tex[19], 6, 1, curC, "boom"));
							}
							break;

						}

					}

					for (int x = whales.size() - 1; x >= 0; x--) {
						GameObject* curC = whales[x];

						if ((b->getPosition().x - curC->getPosition().x)*(b->getPosition().x - curC->getPosition().x) < 0.6 && (b->getPosition().y - curC->getPosition().y)*(b->getPosition().y - curC->getPosition().y) < 0.6) {
							if (gameObjects[0]->getScore() >= 2) {
								int s = (gameObjects[0]->getScore()) - 2;
								gameObjects[0]->setScore(s);
							}
							//bullets.erase(bullets.begin() + i);

							break;

						}

					}




					// Updates bullets
					b->update(deltaTime);



					// Render bullets
					b->render(shader);
				}


				//update breakable coral
				for (int i = 0; i < breakableCoral.size(); i++) {
					// Get the current object
					GameObject* c = breakableCoral[i];

					
					c->update(deltaTime);

					c->render(shader);
				}


				//update and render enemies
				for (int i = 0; i < enemy.size(); i++) {
					// Get the current object
					GameObject* e = enemy[i];

					
					e->update(deltaTime);

					e->render(shader);
				}


				//update boss
				for (int i = 0; i < boss.size(); i++) {
					// Get the current object
					GameObject* bo = boss[i];

					
					bo->update(deltaTime);
					bo->render(shader);
				}



				//update enemyBullets
				for (int i = enemyBullets.size() - 1; i >= 0; i--) {
					// Get the current object
					GameObject* b = enemyBullets[i];

					glm::vec3 p = b->getPosition();

					if (p.x <= -8 || p.x >= 39 || p.y <= -72 || p.y >= 5) {
						enemyBullets.erase(enemyBullets.begin() + i);
					}




					for (int x = 0; x < coralObjects.size(); x++) {
						GameObject* curC = coralObjects[x];

						if ((b->getPosition().x - curC->getPosition().x)*(b->getPosition().x - curC->getPosition().x) < 0.6 && (b->getPosition().y - curC->getPosition().y)*(b->getPosition().y - curC->getPosition().y) < 0.6) {

							enemyBullets.erase(enemyBullets.begin() + i);
							break;
						}

					}

					for (int x = breakableCoral.size() - 1; x >= 0; x--) {
						GameObject* curC = breakableCoral[x];

						if ((b->getPosition().x - curC->getPosition().x)*(b->getPosition().x - curC->getPosition().x) < 0.6 && (b->getPosition().y - curC->getPosition().y)*(b->getPosition().y - curC->getPosition().y) < 0.6) {

							//enemyBullets.erase(enemyBullets.begin() + i);
							break;

						}

					}



					GameObject* player = gameObjects[0];

					if ((b->getPosition().x - player->getPosition().x)*(b->getPosition().x - player->getPosition().x) < 0.6 && (b->getPosition().y - player->getPosition().y)*(b->getPosition().y - player->getPosition().y) < 0.6) {

						enemyBullets.erase(enemyBullets.begin() + i);
						if (shielding.size() > 0) {
							shielding.erase(shielding.begin());
						}
						else if (player->getHealth() > 0) {
							int h = player->getHealth();
							h -= 1;
							player->setHealth(h);
						}
						else {
							exit(0);
						}
						break;
					}



					// Updates bullets
					b->update(deltaTime);

					// Render bullets
					b->render(shader);
				}


				//update bossBullets
				for (int i = bossBullets.size() - 1; i >= 0; i--) {
					// Get the current object
					GameObject* b = bossBullets[i];

					glm::vec3 p = b->getPosition();

					if (p.x <= -8 || p.x >= 39 || p.y <= -72 || p.y >= 5) {
						bossBullets.erase(bossBullets.begin() + i);
					}


					for (int x = 0; x < coralObjects.size(); x++) {
						GameObject* curC = coralObjects[x];

						if ((b->getPosition().x - curC->getPosition().x)*(b->getPosition().x - curC->getPosition().x) < 0.6 && (b->getPosition().y - curC->getPosition().y)*(b->getPosition().y - curC->getPosition().y) < 0.6) {

							bossBullets.erase(bossBullets.begin() + i);
							break;
						}

					}

					for (int x = breakableCoral.size() - 1; x >= 0; x--) {
						GameObject* curC = breakableCoral[x];

						if ((b->getPosition().x - curC->getPosition().x)*(b->getPosition().x - curC->getPosition().x) < 0.6 && (b->getPosition().y - curC->getPosition().y)*(b->getPosition().y - curC->getPosition().y) < 0.6) {

							//enemyBullets.erase(enemyBullets.begin() + i);
							break;

						}

					}



					GameObject* player = gameObjects[0];

					if ((b->getPosition().x - player->getPosition().x)*(b->getPosition().x - player->getPosition().x) < 0.6 && (b->getPosition().y - player->getPosition().y)*(b->getPosition().y - player->getPosition().y) < 0.6) {

						bossBullets.erase(bossBullets.begin() + i);
						if (shielding.size() > 0) {
							shielding.erase(shielding.begin());
						}
						else if (player->getHealth() > 0) {
							int h = player->getHealth();
							h -= 1;
							player->setHealth(h);
						}
						else {
							exit(0);
						}
						break;
					}

					// Updates bullets
					b->update(deltaTime);

					// Render bullets
					b->render(shader);
				}



				//update HEALING 
				for (int i = heal.size() - 1; i >= 0; i--) {
					// Get the current object
					GameObject* b = heal[i];

					glm::vec3 p = b->getPosition();

				
					b->update(deltaTime);

					b->render(shader);
				}


				//update weapon item
				for (int i = weapon.size() - 1; i >= 0; i--) {
					// Get the current object
					GameObject* b = weapon[i];

					glm::vec3 p = b->getPosition();

					b->update(deltaTime);

					b->render(shader);
				}

				//shield upgrade
				for (int i = shield.size() - 1; i >= 0; i--) {
					// Get the current object
					GameObject* b = shield[i];

					glm::vec3 p = b->getPosition();


					b->update(deltaTime);

					b->render(shader);
				}

				//freeze item
				for (int i = freeze.size() - 1; i >= 0; i--) {
					// Get the current object
					GameObject* b = freeze[i];

					glm::vec3 p = b->getPosition();

					b->update(deltaTime);

					b->render(shader);
				}

				//update the shield that goes around the player
				for (int i = shielding.size() - 1; i >= 0; i--) {
					// Get the current object
					GameObject* b = shielding[i];

					glm::vec3 p = gameObjects[0]->getPosition();

					b->setPosition(p);

					b->update(deltaTime);

					b->render(shader);
				}

				//bomb
				for (int i = upgradeBullet.size() - 1; i >= 0; i--) {
					// Get the current object
					GameObject* b = upgradeBullet[i];


					glm::vec3 p = b->getPosition();
					glm::vec3 pp = gameObjects[0]->getPosition();
					if (p.x <= -8 || p.x >= 39 || p.y <= -72 || p.y >= 5) {
						upgradeBullet.erase(upgradeBullet.begin() + i);
					}

					float distance = glm::length(gameObjects[0]->getPosition() - b->getPosition());
					if (distance > 15.0f) {
						upgradeBullet.erase(upgradeBullet.begin() + i);
					}


					for (int x = 0; x < coralObjects.size(); x++) {
						GameObject* curC = coralObjects[x];

						if ((b->getPosition().x - curC->getPosition().x)*(b->getPosition().x - curC->getPosition().x) < 0.6 && (b->getPosition().y - curC->getPosition().y)*(b->getPosition().y - curC->getPosition().y) < 0.6) {

							upgradeBullet.erase(upgradeBullet.begin() + i);
							break;
						}

					}

					for (int x = breakableCoral.size() - 1; x >= 0; x--) {
						GameObject* curC = breakableCoral[x];

						if ((b->getPosition().x - curC->getPosition().x)*(b->getPosition().x - curC->getPosition().x) < 0.6 && (b->getPosition().y - curC->getPosition().y)*(b->getPosition().y - curC->getPosition().y) < 0.6) {
							int s = (gameObjects[0]->getScore()) + 1;
							gameObjects[0]->setScore(s);
							//bullets.erase(bullets.begin() + i);
							breakableCoral.erase(breakableCoral.begin() + x);
							break;

						}

					}

					for (int x = enemy.size() - 1; x >= 0; x--) {
						GameObject* curC = enemy[x];

						if ((b->getPosition().x - curC->getPosition().x)*(b->getPosition().x - curC->getPosition().x) < 0.6 && (b->getPosition().y - curC->getPosition().y)*(b->getPosition().y - curC->getPosition().y) < 0.6) {
							int s = (gameObjects[0]->getScore()) + 2;
							gameObjects[0]->setScore(s);
							upgradeBullet.erase(upgradeBullet.begin() + i);
							enemy.erase(enemy.begin() + x);
							break;

						}

					}

					for (int x = boss.size() - 1; x >= 0; x--) {
						GameObject* curC = boss[x];

						if ((b->getPosition().x - curC->getPosition().x)*(b->getPosition().x - curC->getPosition().x) < 7 && (b->getPosition().y - curC->getPosition().y)*(b->getPosition().y - curC->getPosition().y) < 7) {

							upgradeBullet.erase(upgradeBullet.begin() + i);
							if (curC->getHealth() - 1 != 0) {
								int h = curC->getHealth() - 2;
								curC->setHealth(h);
							}
							else {
								boss.erase(boss.begin() + x);
							}
							break;

						}

					}

					b->update(deltaTime);

					b->render(shader);
				}



				//whales
				for (int i = whales.size() - 1; i >= 0; i--) {
					// Get the current object
					Marine* b = whales[i];
					b->setPos(gameObjects[0]->getPosition());

					b->update(deltaTime);

					b->render(shader);
				}





				//pathfind loop 
				//gameLoop(&gameworld);



				//update graph
				gameworld.update();
				//render graph
				//gameworld.render(shader);


				//UI
				for (int x = 0; x < ammo; ++x) {
					glBindTexture(GL_TEXTURE_2D, tex[2]);
					glm::mat4 scale = glm::scale(glm::mat4(), glm::vec3(1, 0.3, 1));
					glm::mat4 rotate = glm::rotate(glm::mat4(), 90.0f, glm::vec3(0, 0, 1));
					glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), glm::vec3((gameObjects[0]->getPosition()).x - 9 + 0.4*x, (gameObjects[0]->getPosition()).y + 9, 0.0f));
					glm::mat4 transformationMatrix = translationMatrix * rotate*scale;
					shader.setUniformMat4("transformationMatrix", transformationMatrix);
					shader.setUniform2f("offset", glm::vec2(0, 0));
					glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
				}
				for (int x = 0; x < health; ++x) {
					glBindTexture(GL_TEXTURE_2D, tex[5]);
					glm::mat4 scale = glm::scale(glm::mat4(), glm::vec3(0.5, 0.8, 1));
					//glm::mat4 rotate = glm::rotate(glm::mat4(), 90.0f, glm::vec3(0, 0, 1));
					glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), glm::vec3((gameObjects[0]->getPosition()).x - 9 + 0.5*x, (gameObjects[0]->getPosition()).y + 8, 0.0f));
					glm::mat4 transformationMatrix = translationMatrix * scale;
					shader.setUniformMat4("transformationMatrix", transformationMatrix);
					shader.setUniform2f("offset", glm::vec2(0, 0));
					glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
				}
				for (int x = 0; x < score; ++x) {
					glBindTexture(GL_TEXTURE_2D, tex[11]);
					glm::mat4 scale = glm::scale(glm::mat4(), glm::vec3(0.5, 0.7, 1));
					//glm::mat4 rotate = glm::rotate(glm::mat4(), 90.0f, glm::vec3(0, 0, 1));
					glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), glm::vec3((gameObjects[0]->getPosition()).x - 9 + 0.4*x, (gameObjects[0]->getPosition()).y + 7, 0.0f));
					glm::mat4 transformationMatrix = translationMatrix * scale;
					shader.setUniformMat4("transformationMatrix", transformationMatrix);
					shader.setUniform2f("offset", glm::vec2(0, 0));
					glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
				}

				//shop indicator
				glBindTexture(GL_TEXTURE_2D, tex[12]);
				glm::mat4 scale = glm::scale(glm::mat4(), glm::vec3(2.5, 2.5, 1));
				glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(2.5, -47, 0.0f));
				glm::mat4 transformationMatrix = translationMatrix * scale;
				shader.setUniformMat4("transformationMatrix", transformationMatrix);
				glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);


				// Update other events like input handling
				glfwPollEvents();

				// Push buffer drawn in the background onto the display
				glfwSwapBuffers(window.getWindow());
			}
		}
	}
	catch (std::exception &e){
		// print exception and sleep so error can be read
		PrintException(e);
		std::this_thread::sleep_for(std::chrono::milliseconds(100000));
	}

	return 0;
}
