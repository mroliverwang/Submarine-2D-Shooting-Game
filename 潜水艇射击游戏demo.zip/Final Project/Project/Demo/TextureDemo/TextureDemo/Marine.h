#pragma once
#include "GameObject.h"
class Marine :
	public GameObject
{
public:
	Marine(glm::vec3 &entityPos, glm::vec3 &targetPos, GLuint entityTexture, GLint entityNumElements);
	
	glm::vec2 normalize(glm::vec2 vec);
	glm::vec2 turncate(glm::vec2 vec, float max);

	virtual void update(double deltaTime) override;
	virtual void render(Shader &shader) override;
	
	inline void setPos(glm::vec3& s) { target = glm::vec2( s.x,s.y); }

private:

	glm::vec2 target;
	glm::vec2 agent;
	float mass;
	float max_force;
	float max_speed;


};

