#include "Coral.h"

#include "Window.h"



Coral::Coral(glm::vec3 &entityPos, GLuint entityTexture, GLint entityNumElements)
	: GameObject(entityPos, entityTexture, entityNumElements) {}


void Coral::update(double deltaTime) {

	

	// Call the parent's update method to move the object
	GameObject::update(deltaTime);
}


void Coral::render(Shader &shader) {
	shader.enable();
	shader.SetAttributes_sprite();
	// Bind the entities texture
	glBindTexture(GL_TEXTURE_2D, texture);

	glm::mat4 scaleMatrix = glm::scale(glm::mat4(), glm::vec3(2,1.2,1));
	glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), position);

	
	glm::mat4 transformationMatrix = translationMatrix*scaleMatrix;
	shader.setUniformMat4("transformationMatrix", transformationMatrix);
	shader.setUniform2f("offset", glm::vec2(0, 0));
	shader.setUniform4f("basecl", glm::vec4(0, 0, 0, 0));

	// Draw the entity
	glDrawElements(GL_TRIANGLES, numElements, GL_UNSIGNED_INT, 0);
	
}