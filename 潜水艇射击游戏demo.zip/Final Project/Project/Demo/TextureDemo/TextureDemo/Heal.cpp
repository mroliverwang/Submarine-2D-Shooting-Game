#include "Heal.h"
#include <iostream>

#include "Window.h"

/*
	Bullet inherits from GameObject
	It overrides GameObject's update method, so that you can check for input to change the status of bullets
*/

Heal::Heal(glm::vec3 &entityPos, GLuint entityTexture, GLint entityNumElements)
	: GameObject(entityPos, entityTexture, entityNumElements) {}

// Update function for moving the bullet object around
void Heal::update(double deltaTime) {



	//position += velocity * (float)deltaTime;

}

void Heal::render(Shader &shader) {
	shader.enable();
	shader.SetAttributes_sprite();
	// Bind the entities texture
	glBindTexture(GL_TEXTURE_2D, texture);

	glm::mat4 scaleMatrix = glm::scale(glm::mat4(), glm::vec3(1.0, 1, 1));
	glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), position);


	glm::mat4 transformationMatrix = translationMatrix * scaleMatrix;
	shader.setUniformMat4("transformationMatrix", transformationMatrix);
	//make upgrade item moves 
	float t = glfwGetTime();
	shader.setUniform2f("offset", glm::vec2(0.1*sin(2*t),0.1*cos(2*t)));
	shader.setUniform4f("basecl", glm::vec4(0, 0, 0, 0));
	// Draw the entity
	glDrawElements(GL_TRIANGLES, numElements, GL_UNSIGNED_INT, 0);

}