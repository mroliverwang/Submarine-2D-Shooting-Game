#pragma once

extern int window_width_g;
extern int window_height_g;
extern float cameraZoom;
extern float aspectRatio;
// extern GLFWwindow* window;

