#pragma once
#include "GameObject.h"
class Boss : public GameObject
{
public:
	Boss(glm::vec3 &entityPos, GLuint bossTexture, GLuint whirlingTexture, GLint entityNumElements);
	
	virtual void update(double deltaTime) override;
	virtual void render(Shader &shader) override;
	

private: 
	GLuint whirling;
	float length;
	float rotateAngle = 1.1;
	float angle=-1.1;
	float index = 0.001;
	
};

