#pragma once

#include <GL/glew.h>
#include <GL/glfw3.h>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/glm.hpp>
#include <iostream>

#include "Shader.h"

class GameObject {
public:
	GameObject(glm::vec3 &entityPosition, GLuint entityTexture, GLint entityNumElements);

	// Updates the GameObject's state. Can be overriden for children
	virtual void update(double deltaTime);

	// Renders the GameObject using a shader
	virtual void render(Shader &shader);


	// Getters
	inline glm::vec3& getPosition() { return position; }
	inline glm::vec3& getVelocity() { return velocity; }
	inline float& getFacing() { return facing; }
	inline float& getCooldown() { return cooldown; }
	inline float& getAmmo() { return ammo; }
	inline int& getAlert() { return alert; }
	inline int& getHealth() { return health; }
	inline int& getScore() { return score; }
	inline float& getAngle() { return angle; }
	inline int& getUpgrade() { return upgrade; }
	inline float& getTimer() { return timer; }
	inline int& getFreeze() { return freeze; }
	inline int& getShield() { return shieldNumber; }

	// Setters
	inline void setPosition(glm::vec3& newPosition) { position = newPosition; }
	inline void setVelocity(glm::vec3& newVelocity) { velocity = newVelocity; }
	inline void setCooldown(float& newCooldown) { cooldown = newCooldown; }
	inline void setAmmo(float& newAmmo) { ammo = newAmmo; }
	inline void setFacing(float& newfacing) { facing = newfacing; }
	inline void setAlert(int& newalert) { alert = newalert; }
	inline void setHealth(int& newh) { health = newh; }
	inline void setScore(int& news) { score = news; }
	inline void setUpgrade(int& u) { upgrade = u; }
	inline void setTimer(float& tt) { timer = tt; }
	inline void setFreeze(int& f) { freeze = f; }
	inline void setShield(int& s) { shieldNumber = s; }




protected:
	// Object's Transform Variables
	// TODO: Add more transformation variables
	glm::vec3 position;
	glm::vec3 velocity;
	float facing;
	float cooldown;
	float ammo;
	int alert;
	int health;
	float angle;
	int score;
	int upgrade;
	float timer;
	int freeze;
	int shieldNumber;


	// Object's details
	GLint numElements;
	float objectSize; // Not currently being used (will be needed for collision detection when objects have a different scale)

	// Object's texture
	GLuint texture;
};