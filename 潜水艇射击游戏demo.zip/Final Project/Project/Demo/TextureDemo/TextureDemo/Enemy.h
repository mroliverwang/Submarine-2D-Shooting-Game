#pragma once

#include "GameObject.h"

// Inherits from GameObject
class Enemy : public GameObject {
public:
	Enemy(glm::vec3 &entityPos, GLuint entityTexture, GLint entityNumElements, int shieldN);

	// Update function for moving the player object around
	virtual void update(double deltaTime) override;
	virtual void render(Shader &shader) override;
};