#include "PlayerGameObject.h"

#include "Window.h"

/*
	PlayerGameObject inherits from GameObject
	It overrides GameObject's update method, so that you can check for input to change the velocity of the player
*/

PlayerGameObject::PlayerGameObject(glm::vec3 &entityPos, GLuint entityTexture, GLint entityNumElements)
	: GameObject(entityPos, entityTexture, entityNumElements) {}

// Update function for moving the player object around
void PlayerGameObject::update(double deltaTime) {
	
	position += velocity * (float)deltaTime;
	// Checking for player input and changing velocity
	if (glfwGetKey(Window::getWindow(), GLFW_KEY_W) == GLFW_PRESS) {
		velocity *= 0.95f;
		setVelocity(getVelocity() += glm::vec3(0, 0.2, 0));
	}
	else if (glfwGetKey(Window::getWindow(), GLFW_KEY_S) == GLFW_PRESS) {
		facing+=0.0001;
		velocity *= 0.95f;
		setVelocity(getVelocity() += glm::vec3(0, -0.2, 0));
	}
	else if (glfwGetKey(Window::getWindow(), GLFW_KEY_D) == GLFW_PRESS) {
		facing = 1.5;
		velocity *= 0.95f;
		setVelocity(getVelocity() += glm::vec3(0.2, 0, 0));
	}
	else if (glfwGetKey(Window::getWindow(), GLFW_KEY_A) == GLFW_PRESS) {
		facing = -1.5;
		velocity *= 0.95f;
		setVelocity(getVelocity() += glm::vec3(-0.2, 0, 0));
	}
	else {
		velocity *= 0.95f;
	}
	
	
	//collision with edge of the game
	if (position.x <= -8 || position.x >= 39) {
		position += glm::vec3(-0.05, 0.05, 0)*velocity;
		velocity = glm::vec3(-0.5, 0.5, 0)*velocity;
	}




	if (position.y <= -72 || position.y >= 5) {
		position += glm::vec3(0.05, -0.05, 0)*velocity;
		velocity = glm::vec3(0.5, -0.5, 0)*velocity;
	}





	//update the player's ammo and cooldown
	if (cooldown > 0) {
		cooldown -= 2 * (float)deltaTime;
	}

	if (ammo < 5) {
		ammo += 0.8*(float)deltaTime;
	}

	if (upgrade == 1) {
		if (timer > 0) {
			timer -= 2 * (float)deltaTime;
		}
		else {
			upgrade = 0;
			timer = 25.0f;
		}
		

	}



	// Call the parent's update method to move the object
	GameObject::update(deltaTime);
}


void PlayerGameObject::render(Shader &shader) {
	shader.enable();
	shader.SetAttributes_sprite();
	// Bind the entities texture
	glBindTexture(GL_TEXTURE_2D, texture);
	
	glm::mat4 scaleMatrix = glm::scale(glm::mat4(), glm::vec3(facing, 1.5, 1));
	glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), position);


	glm::mat4 transformationMatrix = translationMatrix * scaleMatrix;
	shader.setUniformMat4("transformationMatrix", transformationMatrix);

	shader.setUniform2f("offset", glm::vec2(0, 0));
	shader.setUniform4f("basecl", glm::vec4(0, 0, 0, 0));

	// Draw the entity
	glDrawElements(GL_TRIANGLES, numElements, GL_UNSIGNED_INT, 0);

}