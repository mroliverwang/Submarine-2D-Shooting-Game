#pragma once
#include "GameObject.h"
class paticle : public GameObject
{
public:

	paticle(glm::vec3 & entityPos, GLuint entityTexture, GLint entityNumElements, float destroy_time, GameObject * att, std::string type);
	paticle(glm::vec3 & entityPos, GLuint entityTexture, GLint entityNumElements, float destroy_time, std::string type);
	void update(double deltaTime);
	void renderParticles(Shader & shader, double deltaTime);
	inline std::string getType() { return type; };

	bool donot_destroy_ontime = false;
	bool destroy = false;
	GameObject *attach;
	std::string type;

	
	float time = 0;
	float dt;

};

