#include "Boss.h"



Boss::Boss(glm::vec3 &entityPos, GLuint bossTexture, GLuint whirlingTexture, GLint entityNumElements)
: GameObject(entityPos, bossTexture, entityNumElements) 
{
	health = 20;
	whirling = whirlingTexture;
	glGetTexLevelParameterfv(GL_TEXTURE_2D,0,GL_TEXTURE_WIDTH,&length);
	ammo = 1;
	velocity = glm::vec3(2.0, 0, 0);
	
}
void Boss::update(double deltaTime) {
	rotateAngle += index;
	angle -= index*100;
	if (rotateAngle >= 1.2|| rotateAngle <= -1.2) {
		index *= -1;
	}
	 
	//the timer of the freeze
	if (freeze == 1) {
		if (timer > 0) {
			timer -= 6 * (float)deltaTime;
		}
		else {
			freeze = 0;
			timer = 20.0f;
		}
		velocity = glm::vec3(0, 0, 0);
	}

	if (freeze == 0) {

		if (position.x >= 35.0f) {
			velocity -= glm::vec3(0.5, 0, 0);
		}
		else if (position.x <= 10.0f) {
			velocity += glm::vec3(0.5, 0, 0);
		}
		else if( velocity==glm::vec3(0,0,0)) {
			velocity= glm::vec3(0.5, 0, 0);
		}
	}

	//update the boss's ammo and cooldown
	if (cooldown > 0) {
		cooldown -= 2 * (float)deltaTime;
	}

	if (ammo < 1) {
		ammo += 0.9*(float)deltaTime;
	}



	//velocity *= 0.99;
	// Call the parent's update method to move the object in standard way, if desired
	GameObject::update(deltaTime);
}

void Boss::render(Shader &shader) {
	shader.enable();
	shader.SetAttributes_sprite();
	glm::mat4 scale = glm::scale(glm::mat4(), glm::vec3(8,8.5,8));
	glm::mat4 sca = glm::scale(glm::mat4(), glm::vec3(0.7, 0.7, 1));
	glm::mat4 rot = glm::rotate(glm::mat4(), (rotateAngle * 180) / 3.14f, glm::vec3(0, 0, 1));


	//parent transformation
	glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), position);
	glm::mat4 parent = translationMatrix *scale;




	//turrent transformation
	glm::mat4 localtrans = glm::translate(glm::mat4(1.0f), glm::vec3(0, 0.5, 0));

	glm::mat4 rotateoffset = glm::translate(glm::mat4(), glm::vec3(0, 0.2, 0));

	glm::mat4 offsetundo = glm::translate(glm::mat4(), glm::vec3(0, -0.2, 0));

	glm::mat4 rotateoffset1 = glm::translate(glm::mat4(), glm::vec3(0, 0.1, 0));

	glm::mat4 offsetundo1 = glm::translate(glm::mat4(), glm::vec3(0, -0.1, 0));

	glm::mat4 rotateoffset2 = glm::translate(glm::mat4(), glm::vec3(0, 0.05, 0));

	glm::mat4 offsetundo2 = glm::translate(glm::mat4(), glm::vec3(0, -0.05, 0));



	glm::mat4 local =  localtrans*offsetundo* rot*rotateoffset*sca;
	glm::mat4 local1 = glm::translate(glm::mat4(1.0f), glm::vec3(-0.4, 0, 0)) * offsetundo1* glm::rotate(glm::mat4(), ((rotateAngle+1) * 180) / 3.14f, glm::vec3(0, 0, 1))*rotateoffset1*glm::scale(glm::mat4(), glm::vec3(0.5, 0.5, 1));
	glm::mat4 local2 = glm::translate(glm::mat4(1.0f), glm::vec3(+0.4, 0, 0)) * offsetundo2* glm::rotate(glm::mat4(), ((rotateAngle -1 ) * 180) / 3.14f, glm::vec3(0, 0, 1))*rotateoffset2*glm::scale(glm::mat4(), glm::vec3(0.3, 0.3, 1));
	
	glm::mat4 barreltransformationMatrix = parent*local;


	
	glm::mat4 barreltransformationMatrix1 = parent * local1;
	
	glm::mat4 barreltransformationMatrix2 = parent * local2;
	



	glBindTexture(GL_TEXTURE_2D, whirling);

	shader.setUniformMat4("transformationMatrix", barreltransformationMatrix);
	shader.setUniform2f("offset", glm::vec2(0, 0));
	shader.setUniform4f("basecl", glm::vec4(0, 0, 0, 0));
	glDrawElements(GL_TRIANGLES, numElements, GL_UNSIGNED_INT, 0);

	
	glBindTexture(GL_TEXTURE_2D, whirling);

	shader.setUniformMat4("transformationMatrix", barreltransformationMatrix1);
	shader.setUniform2f("offset", glm::vec2(0, 0));
	shader.setUniform4f("basecl", glm::vec4(0, 0, 0, 0));
	glDrawElements(GL_TRIANGLES, numElements, GL_UNSIGNED_INT, 0);

	glBindTexture(GL_TEXTURE_2D, whirling);

	shader.setUniformMat4("transformationMatrix", barreltransformationMatrix2);
	shader.setUniform2f("offset", glm::vec2(0, 0));
	shader.setUniform4f("basecl", glm::vec4(0, 0, 0, 0));

	glDrawElements(GL_TRIANGLES, numElements, GL_UNSIGNED_INT, 0);


	glDrawElements(GL_TRIANGLES, numElements, GL_UNSIGNED_INT, 0);
	
	
	glBindTexture(GL_TEXTURE_2D, texture);
	shader.setUniformMat4("transformationMatrix", parent);
	shader.setUniform2f("offset", glm::vec2(0, 0));
	shader.setUniform4f("basecl", glm::vec4(0, 0, 0, 0));
	glDrawElements(GL_TRIANGLES, numElements, GL_UNSIGNED_INT, 0);
}
