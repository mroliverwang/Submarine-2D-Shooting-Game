#include "Shield.h"
#include <iostream>

#include "Window.h"

/*
	Bullet inherits from GameObject
	It overrides GameObject's update method, so that you can check for input to change the status of bullets
*/

Shield::Shield(glm::vec3 &entityPos, GLuint entityTexture, GLint entityNumElements)
	: GameObject(entityPos, entityTexture, entityNumElements) {}

// Update function for moving the bullet object around
void Shield::update(double deltaTime) {



	//position += velocity * (float)deltaTime;

}

void Shield::render(Shader &shader) {
	shader.enable();
	shader.SetAttributes_sprite();
	// Bind the entities texture
	glBindTexture(GL_TEXTURE_2D, texture);

	glm::mat4 scaleMatrix = glm::scale(glm::mat4(), glm::vec3(0.5, 0.5, 1));
	glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), position);


	glm::mat4 transformationMatrix = translationMatrix * scaleMatrix;
	shader.setUniformMat4("transformationMatrix", transformationMatrix);
	float t = glfwGetTime();
	//moving around the player
	shader.setUniform2f("offset", glm::vec2(2*sin(2*t), 2*cos(2*t)));
	shader.setUniform4f("basecl", glm::vec4(0, 0, 0, 0));
	// Draw the entity
	glDrawElements(GL_TRIANGLES, numElements, GL_UNSIGNED_INT, 0);

}