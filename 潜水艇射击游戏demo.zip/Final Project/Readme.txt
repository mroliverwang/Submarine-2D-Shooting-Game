运行需要Microsoft Visual Studio。
进入目录\Final Project\Project\Demo\TextureDemo 双击进入TextureDemo.sln文件，用Microsoft Visual Studio打开。F5即可运行。

注意：程序运行需要对应版本的开发工具，如已有所需版本的sdk，可能需要在Microsoft Visual Studio中右键选择当前文件，选择retarget project。


基本操作：
WASD控制反向
J 射击
S+J 向下扔炸弹